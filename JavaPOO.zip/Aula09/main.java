public class main {
    public static void Main (String[] args){
        System.out.println("Ola, Java no VS code");
    }
}
