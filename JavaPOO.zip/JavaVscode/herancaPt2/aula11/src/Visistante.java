public class Visistante extends Pessoa{

    public Visistante(String nome, int idade, String sexo) {
        super(nome, idade, sexo);
        //TODO Auto-generated constructor stub
    }

    //Esse é um exemplo de classe de implementação/pobre

    
}
