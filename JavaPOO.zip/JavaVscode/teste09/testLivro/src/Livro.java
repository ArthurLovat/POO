public class Livro implements Publicacao{
    private String titulo;
    private String autor;
    private int totPag;
    private int pagAtual;
    private boolean aberto;
    private Pessoa leitor; //tipo abstrato para uma variavel, é a forma de pegarmos um dado/atributo/elemento de outra classe

    public String detalhes() {
        return "Livro [\ntitulo=" + titulo + "\n, autor=" + autor + "\n, totPag=" + totPag + "\n, pagAtual=" + pagAtual
                + "\n, aberto=" + aberto + "\n, leitor=" + leitor.getNome() +  ",\n idade: " + leitor.getIdade() + "\n, sexo: " + leitor.getSexo() +"]";
    }

    //metodo builder
    public Livro(String titulo, String autor, int totPag, int pagAtual, boolean aberto, Pessoa p) {
        this.titulo = titulo;
        this.autor = autor;
        this.totPag = totPag;
        this.pagAtual = 0;
        this.aberto = false;
        this.leitor = p;
    }

    //getters e setters
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public String getAutor() {
        return autor;
    }
    public void setAutor(String autor) {
        this.autor = autor;
    }
    public int getTotPag() {
        return totPag;
    }
    public void setTotPag(int totPag) {
        this.totPag = totPag;
    }
    public int getPagAtual() {
        return pagAtual;
    }
    public void setPagAtual(int pagAtual) {
        this.pagAtual = pagAtual;
    }
    public boolean isAberto() {
        return aberto;
    }
    public void setAberto(boolean aberto) {
        this.aberto = aberto;
    }
    public Pessoa getLeitor() {
        return leitor;
    }

    public void setLeitor(Pessoa leitor) {
        this.leitor = leitor;
    }

    @Override
    public void abrir() {
        this.aberto = true;
    }

    @Override
    public void fechar() {
        this.aberto = false;
    }

    @Override
    public void felhear(int p) {
        this.pagAtual = p ;
    }

    @Override
    public void avancarPag() {
        this.pagAtual ++ ;
    }

    @Override
    public void voltarPag() {
        this.pagAtual -- ;
    }

    
    
}
