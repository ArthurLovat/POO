public class Cachorro extends Mamifero{

    public Cachorro(String corPelo) {
        super(corPelo);
        //TODO Auto-generated constructor stub
    }
    @Override
    public void locomover(){
        System.out.println("andando!!");
    }
}
