public class App {
    public static void main(String[] args) throws Exception {
        //Animal n1 = new Animal(); ---> animal é abstrato e não pode ser instanciada 
        Mamifero m1 = new Mamifero("preto");
        Reptil r1 = new Reptil("Verde");
        Peixe p1 = new Peixe();
        Ave a1 = new Ave();    
        Canguru c = new Canguru("Marrom");
        Cachorro ca = new Cachorro("Caramelo");
        //Cobra co = new Cobra();
        //Tartaruga t = new Tartaruga();
        //GoldFish g = new GoldFish();
        //Arara a = new Arara();


        System.out.println("============================");
        m1.setPeso(35.3f);
        m1.setCorPelo("Rosa");
        m1.alimentar();
        m1.locomover();
        m1.emitirSom();

        System.out.println("============================");

        a1.locomover();
        p1.locomover();
        r1.locomover();

        System.out.println("============================");

        c.locomover();
        c.usarBolsa();
        ca.locomover();
    }   
}
