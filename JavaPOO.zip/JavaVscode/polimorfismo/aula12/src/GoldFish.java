public class GoldFish extends Peixe{

}
