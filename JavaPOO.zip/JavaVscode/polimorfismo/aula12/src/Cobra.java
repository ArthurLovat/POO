public class Cobra extends Reptil{

}
