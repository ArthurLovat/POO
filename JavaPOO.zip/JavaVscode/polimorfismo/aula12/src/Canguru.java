public class Canguru extends Mamifero{

    public Canguru(String corPelo) {
        super(corPelo);
        //TODO Auto-generated constructor stub
    }

    @Override
    public void locomover(){
        System.out.println("Pulando!!");
    }
    public void usarBolsa(){
        System.out.println("Usando bolsa!!");
    }

}
