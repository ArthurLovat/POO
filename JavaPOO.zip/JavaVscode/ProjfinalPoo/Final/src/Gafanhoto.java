public class Gafanhoto extends Pessoa{
    //attributes
    private String login;
    private int totAssistido;

    //methods
    public void viuMaisUm(){
        this.totAssistido ++ ;
    }

    //getters and setters
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public int getTotAssistido() {
        return totAssistido;
    }

    public void setTotAssistido(int totAssistido) {
        this.totAssistido = totAssistido;
    }


    @Override
    public void ganharExp() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'ganharExp'");
    }

    //builder
    public Gafanhoto(String nome, int idade, String sexo, float experiencia, String login) {
        super(nome, idade, sexo, experiencia);
        this.login = login;
        this.totAssistido = 0;
    }

    @Override
    public String toString() {
        return "Gafanhoto ["+ super.toString() + "\nlogin=" + login + ", totAssistido=" + totAssistido + "]";
    }
    
    
}
