public class App {
    public static void main(String[] args) throws Exception {
        //intancia e atribuições
        Video video[] = new Video[3];
        Gafanhoto gafanhoto[] = new Gafanhoto[2];
        Visualizacao visualizacao[] = new Visualizacao[5];

        video[0] = new Video("Aula 1 de POO", 0, 0, 0, false);
        video[1] = new Video("Aula 12 de PHP", 0, 0, 0, false);
        video[2] = new Video("Aula 10 de HTML5", 0, 0, 0, false);
        
        gafanhoto[0] = new Gafanhoto("Jubileu", 22, "M", 0, "juba");
        gafanhoto[1] = new Gafanhoto("Cleusa", 12, "F", 0, "Creuzita");

        visualizacao[0] = new Visualizacao(video[2], gafanhoto[0]);
        visualizacao[0].avaliar();
        visualizacao[1] = new Visualizacao(video[1], gafanhoto[0]);
        visualizacao[1].avaliar(87.0f);

        System.out.println("=================================");
        System.out.println("===========VIDEOS==================");
        System.out.println(video[0].toString());
        System.out.println(video[1].toString());
        System.out.println(video[2].toString());
        System.out.println("==================================");
        System.out.println("============GAFANHOTOS=============");
        System.out.println(gafanhoto[0].toString());
        System.out.println(gafanhoto[1].toString());
        System.out.println("===================================");
        System.out.println("============VISUALIZAÇÕES===========");
        System.out.println(visualizacao[0].toString());
        System.out.println(visualizacao[1].toString());
        System.out.println("=====================================");
    }
}