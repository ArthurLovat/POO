public interface Relatorio {
    public void gerarRelatorio();
}
