import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        List<Aluno> alunos = new ArrayList<>();
        List<Curso> cursos = new ArrayList<>();
        int op;

        System.out.println("Oque voce deseja fazer?");
        System.out.println("1 - Cadastrar aluno: ");
        System.out.println("2 - Matricular aluno: ");
        System.out.println("3 - Criar curso: ");
        System.out.println("4 - Gerar relatorio: ");
        System.out.println("0 - SAIR: ");
        System.out.print("Digite um numero: ");
        op = scan.nextInt();

        while (op != 0) {
            switch (op) {
                case 1:{
                    scan.nextLine(); //limpa o buffer
                    System.out.println("========CADASTRO DE ALUNO========");

                    System.out.println("Qual o nome do aluno: "); //inicializa duas variaveis para ser usadas como os paramentros do construtor
                    String nome = scan.nextLine();               
                    System.out.println("Qual o email: ");
                    String email = scan.nextLine();

                    Aluno aluno = new Aluno(nome, email); //ultiliza as variaveis passando como parametro para o builder
                    alunos.add(aluno); //adiciona um novo aluno a lista de alunos

                    System.out.println("Aluno " + nome + " cadastrado com sucesso !!");
                    
                    op = 0; //finalizando o loop
                }
                    break;
                case 2:
                    scan.nextLine();
                    System.out.println("========MATRICULA DE ALONO========");

                    System.out.println("Digite o nome do aluno que deseja matricular");
                    String nome;
                    if (alunos.contains(aluno.getNome(nome))){ //precisa criar a logica - ver se o aluno esta cadastrado!!!!!

                    }
                default:
                    break;
            }
        }
        
    }
}
