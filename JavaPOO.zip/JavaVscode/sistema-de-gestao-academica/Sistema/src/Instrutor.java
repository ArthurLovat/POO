public class Instrutor extends Pessoa {
    //Attributes
    private String especialidade;

    //builder
    public Instrutor(String nome, String email) {
        super(nome, email);
    }

    //methods
    @Override
    public void exibirInfo() {
        
    }

    //getters and setters
    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    
}
