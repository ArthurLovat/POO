import java.util.ArrayList;
public class Curso {
    //attributes
    private String nome;
    private Instrutor instrutor;
    ArrayList<Aluno> alunos = new ArrayList<>();

    //methods
    public void adicionarAluno(Aluno aluno){

    }
    public void listarAlunos(){

    }

    //builder
    public Curso(String nome, Instrutor instrutor, ArrayList<Aluno> alunos) {
        this.nome = nome;
        this.instrutor = instrutor;
        this.alunos = alunos;
    }

    //getters and setters
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public Instrutor getInstrutor() {
        return instrutor;
    }
    public void setInstrutor(Instrutor instrutor) {
        this.instrutor = instrutor;
    }
    public ArrayList<Aluno> getAlunos() {
        return alunos;
    }
    public void setAlunos(ArrayList<Aluno> alunos) {
        this.alunos = alunos;
    }
    
}
