public class Mamifero extends Animal {
    //Attributes
    protected String corPelo;

    //methods
    @Override
    public void emitirSom() {
        System.out.println("Som de mamifero");
    }
    
}
