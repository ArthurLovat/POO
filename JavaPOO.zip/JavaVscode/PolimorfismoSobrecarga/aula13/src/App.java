public class App {
    public static void main(String[] args) throws Exception {
        //Instanciar os objects
        //Animal animal = new Animal(); ---> classes abstratas não poder ser instanciadas
        
        Mamifero mamifero = new Mamifero();
        
        Lobo lobo = new Lobo();

        Cachorro cachorro = new Cachorro();
        
        //exemplo de conceito de sobreposição
        System.out.println("=============================");
        System.out.println("Lobo emitira som!");
        lobo.emitirSom();
        System.out.println("=============================");
        System.out.println("Cachorro emitira som");
        cachorro.emitirSom();
        System.out.println("=============================");
        System.out.println("Mamifero emitira som!!");
        mamifero.emitirSom();
        System.out.println("=============================");

        //Exercitar os conceitos de sobrecarga
        cachorro.reagir("Ola");
        cachorro.reagir("Vai Apanhar");
        cachorro.reagir(11, 45);
        cachorro.reagir(21, 00);
        cachorro.reagir(true);
        cachorro.reagir(2, 12.5f);
        cachorro.reagir(17, 4.5f);
    }
}
