public abstract class Animal {
    //attributes
    protected float peso;
    protected int idade;

    //methods
    public abstract void emitirSom();
        
    
}
